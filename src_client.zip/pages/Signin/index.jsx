import React from "react";
import SigninSection from "./_components/SigninForm";
const index = () => {
  return (
    <>
      <SigninSection />
    </>
  );
};

export default index;
