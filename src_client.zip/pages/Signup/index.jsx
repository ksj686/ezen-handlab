import React from "react";
import SignupForm from "./_components/SignupForm";

const index = () => {
  return (
    <>
      <SignupForm />
    </>
  );
};

export default index;
