// 예: InterviewSection.jsx
import QuestionForm from "@/components/question/QuestionForm";

const InterviewSection = () => {
  const interviewId = "abc123"; // 예시 ID

  return (
    <div className="p-8">
      <h2 className="mb-4 text-xl font-bold">질문 등록</h2>
      <QuestionForm interviewId={interviewId} />
    </div>
  );
};

export default InterviewSection;
