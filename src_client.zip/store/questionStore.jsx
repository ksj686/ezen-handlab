// 📁 store/questionStore.js (선택 사항)
import { create } from "zustand";

export const useQuestionStore = create((set) => ({
  questions: [],
  addQuestion: (question) =>
    set((state) => ({ questions: [...state.questions, question] })),
}));
