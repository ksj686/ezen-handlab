// 📁 components/question/QuestionForm.jsx
import React, { useState } from "react";
import api from "@/utils/api";
import { useQuestionStore } from "@/store/questionStore";

const QuestionForm = ({ interviewId }) => {
  const [content, setContent] = useState("");
  const [type, setType] = useState("PERSONALITY");
  const [order, setOrder] = useState(1);
  const [myAnswer, setMyAnswer] = useState("");
  const [recommended, setRecommended] = useState("");

  const addQuestion = useQuestionStore((state) => state.addQuestion);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      interviewId,
      order,
      type,
      content,
      myAnswer,
      recommended,
      videoUrl: null,
      bookmarked: false,
    };

    try {
      const res = await api.post("/questions", payload);
      addQuestion(res.data); // 상태에 반영
      alert("질문이 등록되었습니다.");
    } catch (err) {
      console.error("질문 등록 실패", err);
      alert("등록 실패");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4">
      <div>
        <label className="block font-semibold">질문 내용</label>
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="w-full rounded border p-2"
          required
        />
      </div>

      <div>
        <label className="block font-semibold">질문 순서</label>
        <input
          type="number"
          value={order}
          onChange={(e) => setOrder(parseInt(e.target.value))}
          className="w-full rounded border p-2"
          required
        />
      </div>

      <div>
        <label className="block font-semibold">질문 유형</label>
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="w-full rounded border p-2"
        >
          <option value="PERSONALITY">인성</option>
          <option value="JOB">직무</option>
        </select>
      </div>

      <div>
        <label className="block font-semibold">내 답변</label>
        <textarea
          value={myAnswer}
          onChange={(e) => setMyAnswer(e.target.value)}
          className="w-full rounded border p-2"
        />
      </div>

      <div>
        <label className="block font-semibold">추천 답변</label>
        <textarea
          value={recommended}
          onChange={(e) => setRecommended(e.target.value)}
          className="w-full rounded border p-2"
        />
      </div>

      <button
        type="submit"
        className="rounded bg-blue-500 px-4 py-2 text-white"
      >
        질문 등록
      </button>
    </form>
  );
};

export default QuestionForm;
