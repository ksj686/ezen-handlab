// 📁 src/services/questionService.js
import prisma from "../utils/prisma.js";

// ✅ 전체 질문 조회 (선택적으로 interviewId로 필터링)
export const getQuestions = async (interviewId = null) => {
  return await prisma.question.findMany({
    where: interviewId ? { interviewId } : undefined,
    orderBy: { order: "asc" },
  });
};

// ✅ 특정 질문 조회
export const getQuestionById = async (id) => {
  return await prisma.question.findUnique({ where: { id } });
};

// ✅ 질문 생성
export const createQuestion = async (data) => {
  return await prisma.question.create({ data });
};

// ✅ 질문 수정
export const updateQuestion = async (id, data) => {
  return await prisma.question.update({
    where: { id },
    data,
  });
};

// ✅ 질문 삭제
export const deleteQuestion = async (id) => {
  return await prisma.question.delete({ where: { id } });
};
