// 📁 src/controllers/questionController.js
import * as questionService from "../services/questionService.js";

// ✅ 전체 조회 (interviewId optional)
export const getQuestions = async (req, res) => {
  const { interviewId } = req.query;
  const questions = await questionService.getQuestions(interviewId);
  res.json(questions);
};

// ✅ 단일 조회
export const getQuestion = async (req, res) => {
  const question = await questionService.getQuestionById(req.params.id);
  if (!question) return res.status(404).send("Question not found");
  res.json(question);
};

// ✅ 생성
export const createQuestion = async (req, res) => {
  const question = await questionService.createQuestion(req.body);
  res.status(201).json(question);
};

// ✅ 수정
export const updateQuestion = async (req, res) => {
  const question = await questionService.updateQuestion(
    req.params.id,
    req.body
  );
  res.json(question);
};

// ✅ 삭제
export const deleteQuestion = async (req, res) => {
  await questionService.deleteQuestion(req.params.id);
  res.status(204).send();
};
